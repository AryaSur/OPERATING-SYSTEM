#include "kernel/param.h"
#include "kernel/fcntl.h"
#include "kernel/types.h"
#include "kernel/riscv.h"
#include "user/user.h"
void pgaccess_test();
int main(int argc, char *argv[]){
    pgaccess_test();
    printf("pgtbltest: all tests succeeded\n");
    exit(0);
}
void pgaccess_test(){
    char *myArr;
    uint64 abits;
    myArr = malloc(32 * PGSIZE);
    pgaccess(myArr, 32, &abits);
    myArr[PGSIZE * 30] += 1;
    myArr[PGSIZE * 11] += 1;
    pgaccess(myArr, 32, &abits);
    for (int i = 0; i < 32; i++)
    {
        if (abits & ((uint64)1 << 2 * i)){
            switch(i % 2) {
                case 0:
                    printf("pgaccess: page %d is dirty  ", i);
                    break;
                case 1:
                    printf("pgaccess: page %d is accessed  ", i);
                    break;
            }
        }
        else{
            switch(i % 2) {
                case 0:
                    printf("pgaccess: page %d is not dirty  ", i);
                    break;
                case 1:
                    printf("pgaccess: page %d is not accessed  ", i);
                    break;
            }
        }
        printf("\n");
    }
    free(myArr);    
    printf("\n");
}
