#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fcntl.h"
#include "kernel/fs.h"

#define BLOCK_SIZE 1024

// Function to print the contents of a block
void disk_block(char *buf) {
    int j;
    for (j = 0; j < BLOCK_SIZE; j++) {
        if (buf[j] == '\0') break;
        fprintf(1, "%c", buf[j]);
    }
    fprintf(1, "\n");
}

int main(int argc, char *argv[]) {
    if (argc != 4) {
        fprintf(2, "Usage: createfile <fileName> <fileSize> <rollNo>\n");
        exit(0);
    }

    char *fileName = argv[1];
    int fileSize = atoi(argv[2]);
    char *rollNo = argv[3];
    int fd = open(fileName, O_CREATE | O_RDWR);
    if (fd < 0) {
        fprintf(1, "Error: Unable to open or create file\n");
        exit(0);
    }

    // Allocate disk blocks and write rollNo in each block
    int j;
    char buf[BLOCK_SIZE];
    for (int j = 0; j < fileSize; j += BLOCK_SIZE) {
        memset(buf, '\0', BLOCK_SIZE);
        strcpy(buf, rollNo);
        write(fd, buf, BLOCK_SIZE);
    }
    close(fd);

    // Re-open the file to get inode number and print file content
    fd = open(fileName, O_RDWR);
    if (fd < 0) {
        fprintf(1, "Error: Unable to reopen file\n");
        exit(0);
    }

    // Get inode number
    struct stat st;
    if (fstat(fd, &st) < 0) {
        fprintf(1, "Error: Unable to get file information\n");
        exit(0);
    }
    fprintf(1, "I-node number: %d\n", st.ino);

    for (j = 0; j < fileSize; j += BLOCK_SIZE) {
        fprintf(1, "Block number: %d\n", j / BLOCK_SIZE);
        memset(buf, '\0', BLOCK_SIZE);
        // Read block contents
        read(fd, buf, BLOCK_SIZE);
        // Print block contents
        fprintf(1, "Block contents: ");
        disk_block(buf);
    }
    close(fd);
    return 0;
}
