#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main()
{
    int arrLocal[10000];
    arrLocal[0] = 0;
    printf("%d\n", arrLocal[0]);
    pgtPrint();
    return 0;
}