#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define READ_END 0
#define WRITE_END 1

int main(int argc, char *argv[]) {
    int parent_to_child[2], child_to_parent[2];
    char buf;

    // Create pipes for communication
    pipe(parent_to_child);
    pipe(child_to_parent);

    int pid = fork();
    if (pid < 0) {
        fprintf(2, "Fork failed\n");
        exit(1);
    } else if (pid == 0) {
        // Child process
        // Close unused ends of pipes
        close(parent_to_child[WRITE_END]);
        close(child_to_parent[READ_END]);

        // Read byte from parent
        read(parent_to_child[READ_END], &buf, 1);

        // Print received message
        printf("%d: received ping\n", getpid());

        // Write byte to parent
        write(child_to_parent[WRITE_END], "1", 1);

        // Close pipes
        close(parent_to_child[READ_END]);
        close(child_to_parent[WRITE_END]);

        exit(0);
    } else {
        // Parent process
        // Close unused ends of pipes
        close(parent_to_child[READ_END]);
        close(child_to_parent[WRITE_END]);

        // Write byte to child
        write(parent_to_child[WRITE_END], "1", 1);

        // Wait for child to send message
        int status;
        wait(&status);

        // Read byte from child
        read(child_to_parent[READ_END], &buf, 1);

        // Print received message
        printf("%d: received pong\n", getpid());

        // Close pipes
        close(parent_to_child[WRITE_END]);
        close(child_to_parent[READ_END]);

        exit(0);
    }
}
