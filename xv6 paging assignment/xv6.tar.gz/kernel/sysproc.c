#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

void _pteprint(pagetable_t pagetable, int level, uint64 value) {
    for (int i = 0; i < 1024; i++) {
        pte_t pte = pagetable[i];

        if (pte & PTE_V) {
            if (pte & PTE_U) {
                // Print the virtual address based on the level
                uint64 virtual_addr = value;
                switch (level) {
                    case 0:
                        virtual_addr |= (uint64)(i << 30);
                        break;
                    case 1:
                        virtual_addr |= (uint64)(i << 21);
                        break;
                    case 2:
                        virtual_addr |= (uint64)(i << 12);
                        break;
                }
                printf("PTE NO.: %d, Virtual page address: %p", i, (void *)virtual_addr);

                // If it's a leaf entry, print physical address
                if (level == 2) {
                    printf(", Physical Page address: %p", (void *)PTE2PA(pte));
                }
                printf("\n");
            }
        }

        if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
            // this PTE points to a lower-level page table.
            uint64 child = PTE2PA(pte);
            _pteprint((pagetable_t)child, level + 1, value);
        }
    }
}


int sys_pgtPrint()
{
  pagetable_t pagetable = myproc() -> pagetable;
  printf("page table %p\n", pagetable);
  _pteprint(pagetable, 0,0);
  return 0;
}



int sys_pgaccess(void)
{
  uint64 startaddr;
  int npage;
  uint64 useraddr;

  argaddr(0, &startaddr);
  argint(1, &npage);
  argaddr(2, &useraddr);

  uint64 bitmask = 0;
  uint64 complement = ~PTE_A;
  struct proc *p = myproc();

  for (int i = 0; i < npage; ++i) {
    pte_t *pte = walk(p->pagetable, startaddr + i * PGSIZE, 0);
    if (*pte & PTE_A) {
      bitmask |= (1 << i);
      *pte &= complement;
    }
  }

  int ret = copyout(p->pagetable, useraddr, (char *)&bitmask, sizeof(bitmask));
  if (ret != 0) {
    return -1;
  }

  return 0;
}